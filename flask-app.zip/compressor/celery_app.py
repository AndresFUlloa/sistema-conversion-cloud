from compressor.app import celery_init_app

app = celery_init_app(None)